import java.util.*;
import java.util.stream.*;
public class Main {

    public static String userName;
    public static int score[] = new int[5];

    public static void main(String[] args) {
        getData();
        int finalAverage = getAverage(score);
        char finalScore = getScore(finalAverage);
        printResults(finalAverage, finalScore);
    }

    public static void getData(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduzca el nombre del alumno:");
        userName = sc.nextLine();
        for(int i = 0; i < score.length; i++){
            Scanner sc2 = new Scanner(System.in);
            System.out.println("Introduzca valor de calificación número: " + (i+1));
            score[i] = sc.nextInt();
        }
    }

    public static int getAverage(int score[]){
        int finalAverage = 0;
        int sum = IntStream.of(score).sum();
        finalAverage = sum / score.length;
        return finalAverage;
    }

    public static char getScore(int average){
        char finalScore = ' ';
        if(average <= 50){
            finalScore = 'F';
        }else if(average >= 51 && average <= 60){
            finalScore = 'E';
        }else if(average >= 61 && average <= 70){
            finalScore = 'D';
        }else if(average >= 71 && average <= 80){
            finalScore = 'C';
        }else if(average >= 81 && average <= 90){
            finalScore = 'B';
        }else if(average >= 91 && average <= 100){
            finalScore = 'A';
        }
        return finalScore;
    }

    public static void printResults(int finalAverage, char finalScore){
        System.out.println("Nombre del alumno: " + userName);
        for(int i = 0; i < score.length; i++){
            System.out.println("Calificación número " + (i+1) + " = " + score[i]);
        }
        System.out.println("Promedio final = " + finalAverage);
        System.out.println("Calificación final = " + finalScore);
    }
}